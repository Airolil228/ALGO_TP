/* Les groupes de TP sont de 2 personnes au maximum, redoublants
   seuls.  Indiquez les membres du groupe de TP sur la ligne suivante
   (commençant par "n>>", sur une seule ligne).
n>>

Avant de déposer ce fichier sur claroline, répondez aux questions suivantes
sur votre avancement (remplacez par "oui" si vous avez fini une étape)

L'affichage de la matrice aléatoire fonctionne :
1>> non

La construction du graphe à partir de la matrice fonctionne :
2>> non

La recherche de chemin entre la 1ere et la dernière ligne de la matrice fonctionne :
3>> non

À partir de quelle valeur de probabilité p la proportion des matrices qui contiennent un
chemin est-elle supérieure à 0,5 ? (pour des matrices de taille 100x100).
4>>

Vérifiez la saisie de vos réponses en lançant le script :
./test_rendu.sh percolation.c

Ne pas modifier cette ligne (nombre de questions):
nbq>>4
*/
#include <stdio.h>
#include <stdlib.h>
#include "include/liste.h"
#include "include/xmalloc.h"
#include "include/affichage.h"
#include "include/graphe_TLA.h"


/****************** structure Tparcours  *************************/ 
/* cette structure sert à stocker les tableaux utilisés pendant le parcours:
  - couleur[]
  - pere[]  : pour stocker l'arborescence de parcours
  - prof[]  : la profondeur des sommets dans l'arborescence.
ainsi que:
  - nb_sommets : le nombre de sommets du graphe
  - nb_sommets_explores : le nombre de sommets explorés par le parcours.
*/
#define BLANC 1 /* valeurs possibles dans le tableau couleur */
#define GRIS 2
#define NOIR 3

typedef struct parcours {
  int nb_sommets; 
  int nb_sommets_explores; 
  int *couleur;
  int *pere;
  int *prof;
} Tparcours;

Tparcours *new_parcours(int n) {
  /* alloue la mémoire pour une structure Tparcours sur un graphe à n
     sommets et retourne un pointeur dessus. Ne remplit pas les tableaux. */
  Tparcours *p;

  p = (Tparcours*) xmalloc(sizeof(Tparcours));
  p->couleur = (int *) xmalloc((n+1)*sizeof(int));
  p->pere = (int *) xmalloc((n+1)*sizeof(int));
  p->prof = (int *) xmalloc((n+1)*sizeof(int));
  p->nb_sommets = n;
  return p;
}

void afficher_parcours(Tparcours *p) {
  /* affiche le contenu des tableaux pere, couleur et prof du parcours
     ainsi que le nombre de sommets explorés */
  int i;

  printf("Contenu des tableaux :\n");
  printf("          ");
  for (i=1; i<= p->nb_sommets; i++) 
    printf("%3d",i);
  printf("\ncouleur : ");
  for (i=1; i<=  p->nb_sommets; i++) {
    if (p->couleur[i] == BLANC) printf("  B");
    if (p->couleur[i] == NOIR) printf("  N");
    if (p->couleur[i] == GRIS) printf("  G");
  } 
  printf("\npere    : ");
  for (i=1; i<=  p->nb_sommets; i++)
    if (p->couleur[i] != BLANC) 
      printf("%3d",p->pere[i]);
    else
      printf("  _");
  printf("\nprof    : ");
  for (i=1; i<=  p->nb_sommets; i++)
    if (p->couleur[i] != BLANC) 
      printf("%3d",p->prof[i]);
    else
      printf("  _");
  printf("\n");  
  printf("Nombre de sommets explorés : %d\n", p->nb_sommets_explores); 
}

void detruit_parcours(Tparcours *p) {
    /*  Pour liberer la mémoire alloué pour le parcours p.  Utile surtout pour
    la fin du tp quand il faut générer plusieurs matrices, dans ce cas si
    on ne libere pas la mémoire une fois qu'une matrice a été parcourue, on
    risque de saturer la mémoire.
  */
  free(p->couleur);
  free(p->pere);
  free(p->prof);
  free(p);
}
/****************** fin structure Tparcours *********************/ 



/****************** structure Tmatrice *********************/ 
#define VIDE 0  /* valeurs possibles dans la matrice */
#define PLEIN 1

typedef struct matrice {
  int h; /* hauteur */
  int l; /* largeur */
  int *mat; /* chaque case du tableau contient VIDE ou PLEIN */
} Tmatrice;


Tmatrice *gen_matrice(int hauteur, int largeur, double proba) {
  /* retourne un pointeur sur une matrice générée aléatoirement */
  /* proba est la probabilité qu'une case de la matrice soit vide. */
  Tmatrice *m;
  int i;
  
  m = (Tmatrice *) xmalloc(sizeof(Tmatrice));
  m->h = hauteur;
  m->l = largeur;
  m->mat = (int *) xmalloc((largeur*hauteur+1)*sizeof(int));
  for (i = 1; i <= largeur*hauteur; i++) {
    if ((double)random()/RAND_MAX < proba) 
      m->mat[i] = VIDE;
    else
      m->mat[i] = PLEIN;
  }
  return m;
}

void detruit_matrice(Tmatrice *m) {
  /*  Pour liberer la mémoire alloué pour la matrice m.  Utile surtout pour
    la fin du tp quand il faut générer plusieurs matrices, dans ce cas si
    on ne libere pas la mémoire une fois qu'une matrice a été parcourue, on
    risque de saturer la mémoire.
  */
  free(m->mat);
  free(m);
}
/****************** fin structure Tmatrice *********************/ 


/****************** Affichage *********************/ 

/* Couleurs utilisées pour l'affichage (cf affichage.h) */
#define COUL_BLANC coul_gris(23)
#define COUL_GRIS coul_gris(14) //coul_rvb(2,2,3) 
#define COUL_NOIR coul_gris(5)
#define COUL_PLEIN coul_rvb(3,2,1)

void affiche_legende_couleurs() {
  /* affiche la legende des couleurs, comme son nom l'indique */
  printf("Legende :\n");
  printf(" Case pleine : "); couleur_fond(COUL_PLEIN); printf(" "); 
  reset_couleurs();
  printf("     Case vide non explorée : "); couleur_fond(COUL_BLANC); 
  printf(" "); reset_couleurs();
  printf("\n Cases explorées : "); 
  printf(" NOIR : "); couleur_fond(COUL_NOIR); printf(" "); reset_couleurs();
  printf("    GRIS : "); couleur_fond(COUL_GRIS); printf(" "); reset_couleurs();
  printf("\n");
}

void affiche_mat(Tmatrice *m, Tparcours *p) {
  /* Si p == NULL, affiche juste la matrice m à l'écran.
     Si p != NULL, fait l'affichage en utilisant des couleurs differentes
     pour les sommets selon la valeur de p->couleur. Pour afficher la
     legende des couleurs, utiliser la fonction affiche_legende_couleurs
     ci-dessus. */
  int i, j, numero_sommet;
  int h = m->h;
  int l = m->l;
  
  numero_sommet = 1;
  for (j = 1; j <= h; j++) {
    for (i = 1; i <= l; i++) {
      /* choix de la couleur de fond */
      if (m->mat[numero_sommet] == PLEIN) {
	couleur_fond(COUL_PLEIN);
      } else if (p == NULL) {
	couleur_fond(COUL_BLANC);
      } else {
	if (p->couleur[numero_sommet] == BLANC) couleur_fond(COUL_BLANC);
	if (p->couleur[numero_sommet] == GRIS)  couleur_fond(COUL_GRIS);
	if (p->couleur[numero_sommet] == NOIR)  couleur_fond(COUL_NOIR);
      }
      printf(" ");
      numero_sommet++;
    }
    reset_couleurs();
    printf("\n");
  }
  printf("\n");
}
/****************** fin affichage *********************/ 

Tgraphe *gen_graphe(Tmatrice *m) {
  /* Retourne le graphe correspondant à la matrice passée en paramètre. */
  Tgraphe *g;

  g = creer_graphe(m->h * m->l); // crée un graphe de la même taille que la matrice.

  
  /* à completer. Il faut maintenant rajouter les arêtes du graphe.  

     Il faut avoir bien compris comment le graphe est construit à partir de
     la matrice (voir énoncé). */

  return g;
}




void visiter(int s, Tgraphe *g, Tparcours *p, Tmatrice *m) {
  /* Visite le sommet s. Idem programme parcours */
  /* Le paramètre m ne sert que si on veut afficher la matrice pendant le
     parcours (pour faire une sorte d'animation du parcours) */
   /* ..... */
}


int percolation(Tgraphe *g, Tmatrice *m) {
  /* Retourne 1 s'il y a un chemin de la 1ere à la derniere ligne de la
     matrice et 0 sinon */
  /* Utilise certainement la fonction visiter... à vous de voir comment */  

  return 0; // à modifier
}


int main(int argc, char **argv) {
  int h, l;
  double proba;

  if (argc != 4) {
    fprintf(stderr, "Il faut 3 paramètres : hauteur largeur proba\n");
    exit(1);
  }
  h = atoi(argv[1]);
  l = atoi(argv[2]);
  proba = atof(argv[3]);
  srandom(0);
  printf("hauteur = %d,  largeur = %d,  proba = %f\n", h, l, proba);

  /* à compléter */

  exit(0);
}
