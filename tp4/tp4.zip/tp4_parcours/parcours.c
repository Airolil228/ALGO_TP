/*
   Les groupes de TP sont de 2 personnes au maximum, redoublants
   seuls.  Indiquez les membres du groupe de TP sur la ligne suivante
   (commençant par "n>>", sur une seule ligne).
n>>

Avant de déposer ce fichier sur claroline, répondez aux questions suivantes
sur votre avancement (remplacez par "oui" si vous avez fini une étape)

La fontion visiter est faite et fonctionne :
1>> non

La fonction chemin est faite et fonctionne :
2>> non

Comment tester si le chemin entre le sommet de départ et de destination existe ? 
3>>
3>>

Vérifiez la saisie de vos réponses en lançant le script :
./test_rendu.sh parcours.c

Ne pas modifier cette ligne (nombre de questions):
nbq>>3
*/
#include <stdio.h>
#include <stdlib.h>
#include "include/liste.h"
#include "include/xmalloc.h"
#include "include/graphe_TLA.h"


/****************** structure Tparcours  *************************/ 
/* cette structure sert à stocker les tableaux utilisés pendant le parcours:
  - couleur[] :  couleur[i] devra valoir soit BLANC, GRIS ou NOIR (pseudo-constantes définies ci-dessous)  
  - pere[]  : pour stocker l'arborescence de parcours. 
              par convention on devra avoir pere[racine] = 0
  - prof[]  : la profondeur des sommets dans l'arborescence.
              On devra avoir : prof[racine] = 0 et pour les autres sommets : prof[x] = prof[pere[x]] + 1 
ainsi que:
  - nb_sommets : le nombre de sommets du graphe
  - nb_sommets_explores : le nombre de sommets explorés par le parcours.
  Cette structure devra être initialisée avant de commencer le parcours.
*/
#define BLANC 1 /* valeurs possibles dans le tableau couleur */
#define GRIS 2
#define NOIR 3

typedef struct parcours {
  int nb_sommets; 
  int nb_sommets_explores; 
  int *couleur;
  int *pere;
  int *prof;
} Tparcours;

Tparcours *new_parcours(int n) {
  /* alloue la mémoire pour une structure Tparcours sur un graphe à n
     sommets et retourne un pointeur dessus. 
     Ne fait aucune initialisation à part l'initialisation de nb_sommets. */
  Tparcours *p;

  p = (Tparcours*) xmalloc(sizeof(Tparcours));
  p->couleur = (int *) xmalloc((n+1)*sizeof(int));
  p->pere = (int *) xmalloc((n+1)*sizeof(int));
  p->prof = (int *) xmalloc((n+1)*sizeof(int));
  p->nb_sommets = n;
  return p;
}

void afficher_parcours(Tparcours *p) {
  /* affiche le contenu des tableaux pere, couleur et prof du parcours
     ainsi que le nombre de sommets explorés */
  int i;

  printf("Contenu des tableaux :\n");
  printf("          ");
  for (i=1; i<= p->nb_sommets; i++) 
    printf("%3d",i);
  printf("\ncouleur : ");
  for (i=1; i<=  p->nb_sommets; i++) {
    if (p->couleur[i] == BLANC) printf("  B");
    if (p->couleur[i] == NOIR)  printf("  N");
    if (p->couleur[i] == GRIS)  printf("  G");
  } 
  printf("\npere    : ");
  for (i=1; i<=  p->nb_sommets; i++)
    if (p->couleur[i] != BLANC) 
      printf("%3d",p->pere[i]);
    else
      printf("  _");
  printf("\nprof    : ");
  for (i=1; i<=  p->nb_sommets; i++)
    if (p->couleur[i] != BLANC) 
      printf("%3d",p->prof[i]);
    else
      printf("  _");
  printf("\n");  
  printf("Nombre de sommets explorés : %d\n", p->nb_sommets_explores); 
}
/****************** fin structure Tparcours *********************/ 

void visiter(int s, Tgraphe *g, Tparcours *p) {
  /* Visite du sommet s. Cette fonction met à jour la structure p. */
  /* La structure p doit avoir été initialisée (à vous de voir comment) */
  /* Il faut utiliser la fonction liste_succ() pour accéder aux successeurs de s (cf graphe_TLA.h). */
  /* Pour obtenir l'indentation de l'affichage comme dans les fichiers de
     log (les espaces au début des lignes "début visiter" et "fin
     visiter"), il faut utiliser le tableau profondeur (le nombre d'espaces
     est égal à 3 fois la profondeur du sommet).
  */
}

Liste *chemin(Tparcours *p, int dest) {
  /* Retourne une liste de sommets contenant le chemin de la racine de
     l'arborescence de parcours jusqu'au sommet dest en utilisant le
     tableau p->pere[].  Vous pourrez ensuite utiliser la fonction
     d'affichage d'une liste (fournie dans liste.h) pour afficher le
     chemin.
 
     Il faut évidement avoir rempli la structure p avant d'appeler
     cette fonction (et donc avoir fait le parcours récursif).
*/
  return NULL; // à modifier
}


int main(int argc, char **argv) {
  Tgraphe *g;
  int r; /* r est le sommet de départ du parcours (donc aussi la racine de l'arbo de parcours) */
  int dest; /* dest est l'eventuel sommet de destination */

  if (argc < 2 || argc > 3) {
    fprintf(stderr, "usage: %s racine [dest]\n", argv[0]);
    fprintf(stderr, " racine : sommet de départ du parcours\n");
    fprintf(stderr, " dest   : sommet de destination du parcours (facultatif) \n");
    exit(1);
  }

  g = lire_graphe(); /* lit le graphe sur l'entrée standard.*/
  afficheTLA(g);
  printf("\n");
  r = atoi(argv[1]);
  if (r < 1 || r > nb_sommets(g)) {
    fprintf(stderr, "Erreur, le sommet de départ du parcours %d n'est pas compris entre 1 et %d\n", r, nb_sommets(g));
    exit(3);
  }
  if (argc == 3) {
    dest = atoi(argv[2]);
    if (dest < 1 || dest > nb_sommets(g)) {
      fprintf(stderr, "Erreur, le sommet de destination du parcours %d n'est pas compris entre 1 et %d\n", dest, nb_sommets(g));
      exit(3);
    }
  }

  /* à completer */
  
  /* Creer une struture parcours et l'initialiser: 

     Vous pouvez utiliser la fonction d'affichage du parcours définie
     plus haut pour afficher le contenu de la structure parcours.*/
  
  /* Lancer le parcours à partir du sommet r : */
  
  /* Afficher le chemin de r à dest s'il existe. */
  /* Comment tester si le chemin existe ? Répondez dans les
   * commentaires plus haut.*/

  exit(0);
}
