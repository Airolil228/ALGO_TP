#!/usr/bin/env bash

####### parcours complets des graphes
### ex1
echo "########## ../parcours 1 < ../graphes_exemples/ex1.txt"
../parcours 1 < ../graphes_exemples/ex1.txt
echo

### ex2
echo "########## ../parcours 1 < ../graphes_exemples/ex2.txt"
../parcours 1 < ../graphes_exemples/ex2.txt
echo

# graphes TD
for g in G1 G2 G3 G4; do
    echo "########## ../parcours 1 < ../graphes_exemples/$g.txt"
    ../parcours 1 < ../graphes_exemples/$g.txt
    echo
done
