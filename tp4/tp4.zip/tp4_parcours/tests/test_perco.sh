#!/bin/bash


echo "# ../percolation 20 50 0.6"
../percolation 20 50 0.6
echo "#######################################"
echo


echo "# ../percolation 20 50 0.62"
../percolation 20 50 0.62
echo "#######################################"
echo

echo "# ../percolation 20 100 0.47"
../percolation 20 100 0.47
