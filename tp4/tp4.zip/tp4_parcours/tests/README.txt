
***********************************************************
********* Première partie : Tests à faire avec parcours :
***********************************************************

 * Comparez la sortie de votre programme avec le contenu de "parcours_log.txt".
   Les lignes commençant par "#" indiquent la commande utilisée.
   Le reste est l'affichage de la commande.

   Une fois que vous avez vérifié que vous avez la même chose sur les
   2 ou 3 premiers test, vous pouvez ensuite faire tous les tests d'un coup
   avec le script test_parcours.sh :

   ./test_parcours.sh > mon_parcours_log.txt
   diff parcours_log.txt mon_parcours_log.txt

   Vous pouvez utiliser l'option -w de diff pour que diff ne prenne pas en
   compte les différences dans le nombre de caractères espace.

 * Les graphes G1 à G4 sont ceux du TD, vous pouvez donc comparer avec les résultats du TD.

 * Une fois que vous avez écrit la fonction chemin, comparez vos résultats avec
   le contenu de "chemins_log.txt".

   De la même façon, vous pouvez faire tous les tests avec :
   ./test_chemins.sh > mon_chemins_log.txt
   diff chemins_log.txt mon_chemins_log.txt
   
 *** Graphe chevre choux loup: Le graphe représentant le pb de la
    traversée d'une riviére avec un loup, une chévre et un choux (cf
    exo 6.1 de la feuille de td).
    Dans ce graphe il faut trouver un chemin du sommet 1 au sommet 24.

    ../parcours 1 24 < ../graphes_exemples/graphe_chevre_loup_choux.txt

    Pour afficher la solution de façon lisible, utilisez le script
    aff_sol.sh en lui donnant le chemin sur son entrée standard:

    ./aff_sol.sh liste_arcs.txt < chemin.txt
    
    Le contenu du fichier chemin.txt est le chemin trouvé par votre algo,
    par ex:
    1 4 12 2 ...

    Il faudra donc creer ce fichier en faisant un copier-coller du
    chemin affiché par votre algo. (Vous pouvez aussi directement
    faire un copier-coller sur l'entrée standard sans creer le fichier
    chemins.txt).

 *** Graphe choux_etc...: Généralisation du jeu chèvre choux loup avec
    un singe, un chasseur, une machine à laver ...
    Jeu disponible sur http://www.lexaloffle.com/bbs/?tid=2010
    (appuyer sur 'z' pour commencer le jeu).

    Un parcours sur le graphe graphe_choux_etc.txt entre les sommets 1 et
    256 permet de trouver une solution.

    ../parcours 1 256 < ../graphes_exemples/graphe_choux_etc.txt

    Pour afficher la solution de façon lisible, utilisez le script
    aff_sol.sh comme pour le graphe précédent (cf. plus haut)

***********************************************************
********* Seconde partie : Tests à faire avec percolation :
***********************************************************

Pour afficher le contenu des fichiers, il vaut mieux utiliser la
commande "less" avec l'option "-R" ce qui permet d'afficher
correctement les couleurs.

Par ex :
less -R perco_log1.txt

une fois que la commande less est lancée, on peut se déplacer dans le
fichier avec les flèches. Pour sortir, appuyer sur la touche 'q'.

  * Contenu de perco_log1.txt :

    Voir le contenu de perco_log1.txt pour savoir ce que votre programme doit
    afficher (le TLA et la matrice).


  * Modifiez votre programme pour qu'il n'affiche plus le tla et comparez
    avec le contenu de perco_log2.txt. Ce fichier est généré à l'aide du script
    test_perco.sh :

    ./test_perco.sh > mon_perco_log2.txt
    diff mon_perco_log2.txt perco_log2.txt

  * Vous pouvez sur de petites matrices (par ex 10x10) faire un affichage
    dans la fonction visiter (avec la fonction affiche_mat). De cette
    façon, vous verrez la progression du parcours au fur et à mesure. Pour
    cela, il faudra rajouter la matrice comme paramètre à la fonction
    visiter.
    
