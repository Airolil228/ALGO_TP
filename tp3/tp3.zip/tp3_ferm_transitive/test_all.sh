#!/usr/bin/env bash

./test_inter.sh
./test_union.sh
./test_prod.sh
./test_ferm3.sh
./test_ferm4.sh
