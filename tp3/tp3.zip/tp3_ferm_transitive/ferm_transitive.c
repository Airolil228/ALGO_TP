/* Il y a parfois des questions dans l'énoncé du TP. Vous devez
   indiquer vos réponses en complétant Les lignes commençant par "X>>"
   (X étant un nombre ou une lettre pour identifier la question).

   Les groupes de TP sont de 2 personnes au maximum, redoublants
   seuls.  Indiquez les membres du groupe de TP sur la ligne suivante
   (commençant par "n>>", sur une seule ligne).
n>>

Avant de déposer ce fichier sur l'ENT, répondez aux questions suivantes
sur votre avancement (remplacez par "oui" si vous avez fini une étape)

La fonction union_g() est finie et testée (en comparant avec les log):
1>> non

La fonction intersection() est finie et testée (en comparant avec les log):
2>> non

La fonction produit() est finie et testée (en comparant avec les log):
3>> non

La fonction ferm_transitive_n4() est finie et testée (en comparant avec les log):
4>> non

La fonction ferm_transitive_n3() est finie et testée (en comparant avec les log):
5>> non

Taille maximum d'un graphe tel que le calcul de la fermeture avec l'algo en n3
prenne moins de 5s:
6>>

Taille maximum d'un graphe tel que le calcul de la fermeture avec l'algo en n4
prenne moins de 5s:
7>>

Comment varie le temps de calcul si vous doublez la taille des graphes
(pour chaque algorithme) ?  Est-ce en accord avec la complexité
théorique ?
8>>
8>>
(Vous pouvez rajouter des lignes commençant par 8>> si necessaire).

Vérifiez la saisie de vos réponses en lançant le script :
./test_rendu.sh ferm_transitive.c

Ne pas modifier cette ligne (nombre de questions):
nbq>>8
*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "include/graphe_MADJ.h"

/* Ces fonctions sont définies plus bas */
TGraphe *intersection(TGraphe *G1, TGraphe *G2);
TGraphe *union_g(TGraphe *G1, TGraphe *G2);
TGraphe *produit(TGraphe *G1, TGraphe *G2);

void usage() {
  fprintf(stderr, "Usage:\n./ferm_transitive t\n  Fait des test avec les fonctions sur les graphes définies dans\n  include/graphe_MADJ.h\n\ncat fich1 fich2 | ./ferm_transitive i\ncat fich1 fich2 | ./ferm_transitive u\ncat fich1 fich2 | ./ferm_transitive p\n  Calcule l'intersection (i); l'union (u) ou le produit (p) de deux\n  graphes.  Les graphes sont lus sur l'entrée standard. L'utilisation\n  avec le 'cat' permet de lire les graphes dans fich1 et fich2 (qui\n  doivent contenir des graphes, utiliser les fichiers dans\n  graphes_exemples/ ).\n\ncat fich |  ./ferm_transitive 3\ncat fich |  ./ferm_transitive 4\n  Calcule la fermeture transitive en utilisant l'algorithme en O(n^4)\n  ou l'algorithme de Roy Warshall en O(n^3).\n  Le graphe est lu sur l'entrée standard, le cat permet de lire le graphe\n  dans le fichier fich.\n");
  exit(1);
}


/*******************************************************/
/************** Fermeture transitive en O(n^4) *********/
/*******************************************************/

TGraphe *ferm_transitive_n4 (TGraphe *G){
  /* Algorithme en O(n^4) de fermeture transitive.
     Retourne la fermeture transitive de G.
     Votre algorithme doit calculer et afficher les puissances de G : G^2, G^3 ...
     Vous pouvez utiliser des fonctions auxiliaires.
   */
  return creer_graphe(0); /* à modifier: doit retourner la fermeture transitive.*/
}

/*******************************************************/
/**** Fermeture transitive (Roy Warshall) en O(n^3) ****/
/*******************************************************/

TGraphe *ferm_transitive_n3 (TGraphe *G){
  /* Algorithme de Roy Warshall en O(n^3) 
     Retourne la fermeture transitive de G.
     Votre algorithme doit calculer et afficher les différentes étapes
     d'ajout des arcs dans G (cf fichiers de log).
     Vous pouvez utiliser des fonctions auxiliaires. */
  return creer_graphe(0); /* à modifier: doit retourner la fermeture transitive.*/
}

/********************************************************************/
void calc_et_affiche_ferm(int a) {
  /* Lit un graphe sur l'entrée standard et affiche sa fermeture
   * transitive calculée avec : ferm_transitive_n3 si a==3 ou
   * ferm_transitive_n4 si a==4.
   * Appelé dans main().
   */
  TGraphe *G, *Gferm;
  
  printf("Lecture du graphe G sur l'entrée standard\n");
  G = lire_graphe(); /* lit le graphe sur l'entrée standard. */
  printf("Matrice d'adjacence du graphe G :\n");
  afficheMADJ(G);

  printf("\nCalcul de la fermeture transitive...\n");
  if (a == 3) {
    Gferm = ferm_transitive_n3(G);
  } else {
    Gferm = ferm_transitive_n4(G);
  }

  printf("Fermeture transitive de G :\n");
  afficheMADJ(Gferm);
  
  detruit_graphe(Gferm);
  detruit_graphe(G);
}


/*******************************************************/
/************** Intersection de graphes ****************/
/*******************************************************/
TGraphe *intersection(TGraphe *G1, TGraphe *G2){
  /* Retourne le graphe intersection de G1 et G2. 
     G1 et G2 doivent avoir le même nombre de sommets. */
  /* à completer */
  
  return creer_graphe(0); /* à modifier: doit retourner l'intersection.*/
}


/*******************************************************/
/**************** Union de graphes *********************/
/*******************************************************/
TGraphe *union_g(TGraphe *G1, TGraphe *G2){
  /* Retourne le graphe union de G1 et G2. 
     G1 et G2 doivent avoir le même nombre de sommets. */
  /* à completer */
  
  return creer_graphe(0); /* à modifier: doit retourner l'union.*/
}


/*******************************************************/
/************** Produit de graphes *********************/
/*******************************************************/
TGraphe *produit(TGraphe *G1, TGraphe *G2){
  /* Retourne le graphe produit de G1 et G2. 
     G1 et G2 doivent avoir le même nombre de sommets. */
  /* à completer */
  
  return creer_graphe(0); /* à modifier: doit retourner le produit.*/
}


/*******************************************************/
void calc_et_affiche(char op) {
  /* Lit deux graphes sur l'entrée standard et effectue l'opération
     définie par op: 'i' : intersection; 'u' : union; 'p' : produit.
     Affiche ensuite le graphe résultat.
     Appelé dans main().
  */
  TGraphe *G1, *G2, *Gres;

  printf("Lecture du graphe G1 sur l'entrée standard\n");
  G1 = lire_graphe(); /* lit le graphe sur l'entrée standard. */
  printf("Matrice d'adjacence du graphe G1 :\n");
  afficheMADJ(G1);
  printf("Lecture du graphe G2 sur l'entrée standard\n");
  G2 = lire_graphe(); /* lit le graphe sur l'entrée standard. */
  printf("Matrice d'adjacence du graphe G2 :\n");
  afficheMADJ(G2);

  printf("\nCalcul du résultat...\n");
  switch (op) {
  case 'p':
    Gres = produit(G1, G2);
    break;
  case 'u':
    Gres = union_g(G1, G2);
    break;
  case 'i':
    Gres = intersection(G1, G2);
    break;
  }

  printf("Résultat :\n");
  afficheMADJ(Gres);
  
  detruit_graphe(Gres);
  detruit_graphe(G2);
  detruit_graphe(G1);
}


/*******************************************************/
/************** main ***********************************/
/*******************************************************/
void tst_fct_graphe() {
  /* Exemple d'utilisation des fonctions sur les graphes (ces
   * fonctions sont dans include/graphe_MADJ.h). */
  TGraphe *G;  

  G = creer_graphe(5); /* G: graphe à 5 sommets sans arcs */
  ajoute_arc(3,4,G);   /* on ajoute les arcs à G */
  ajoute_arc(1,5,G);
  ajoute_arc(1,5,G);   /* ajouter un arc déjà dans le graphe ne change rien*/
  ajoute_arc(2,2,G);
  enleve_arc(1,3,G);   /* enlever un arc qui n'est pas dans le graphe
                        * ne change rien*/
  printf("Le graphe G a %d sommets\n", nb_sommets(G));
  afficheMADJ(G);
 
  if (arc(3,4,G))
     printf("Le graphe G contient l'arc (3,4)\n");
  else
    printf("Le graphe G ne contient pas l'arc (3,4)\n");

  if (arc(5,1,G))
     printf("Le graphe G contient l'arc (5,1)\n");
  else
    printf("Le graphe G ne contient pas l'arc (5,1)\n");
  detruit_graphe(G);
}

int main(int argc, char* argv[]){
  
  if (argc != 2)  /* il faut un parametre. */
    usage();

  switch (argv[1][0]) {  /* 1er caractère du premier paramétre */
  case 't':
    printf("Test des fonctions sur un graphe :\n");
    tst_fct_graphe();
    break;
  case 'p':
    printf("Produit de 2 graphes :\n");
    calc_et_affiche('p');
    break;
  case 'u':
    printf("Union de 2 graphes :\n");
    calc_et_affiche('u');
    break;
  case 'i':
    printf("Intersection de 2 graphes :\n");
    calc_et_affiche('i');
    break;
  case '3':
    printf("Fermeture transitive d'un graphe, algo de Roy Warshall en O(n^3) :\n");
    calc_et_affiche_ferm(3);
    break;
  case '4':
    printf("Fermeture transitive d'un graphe, algo en O(n^4) :\n");
    calc_et_affiche_ferm(4);
    break;
  default:
    usage();
  }
  exit(0);
}
