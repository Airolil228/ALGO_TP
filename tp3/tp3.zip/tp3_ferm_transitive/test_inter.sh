#!/usr/bin/env bash

echo $(basename $0)
if [[ $(basename $0) == "test_union.sh" ]]; then
    n=union; o=u
elif [[ $(basename $0) == "test_inter.sh" ]]; then
    n=intersection; o=i
elif [[ $(basename $0) == "test_prod.sh" ]]; then
    n=produit; o=p
else
    exit 4 
fi

mkdir -p meslog/

pref="graphes_exemples"
lg1="ga_3.txt  gb_3.txt"
lg2="gc_3.txt  gd_3.txt ge_3.txt"
dest="meslog/${n}_3.log"
rm -f $dest
for g1 in $lg1; do
    for g2 in $lg2; do
        cmd="cat $pref/$g1 $pref/$g2 | ./ferm_transitive $o"
        echo -e "\n******** Debut calcul $n entre $g1 et $g2" >> $dest
        echo "*** commande: $cmd" >> $dest
        cmd="$cmd >> $dest"
        echo $cmd
        eval $cmd
    done
done

lg1="gf_5.txt"
lg2="gg_5.txt  gh_5.txt"
dest="meslog/${n}_5.log"
rm -f $dest
for g1 in $lg1; do
    for g2 in $lg2; do
        cmd="cat $pref/$g1 $pref/$g2 | ./ferm_transitive $o"
        echo -e "\n******** Debut calcul $n entre $g1 et $g2" >> $dest
        echo "*** commande: $cmd" >> $dest
        cmd="$cmd >> $dest"
        echo $cmd
        eval $cmd
    done
done


# on peut faire un
# diff -qs meslog/ log/

