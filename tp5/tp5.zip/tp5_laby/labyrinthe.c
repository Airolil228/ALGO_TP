/*
   Les groupes de TP sont de 2 personnes au maximum, redoublants
   seuls.  Indiquez les membres du groupe de TP sur la ligne suivante
   (commençant par "n>>", sur une seule ligne).
n>>

Avant de déposer ce fichier sur l'ENT, répondez aux questions suivantes
sur votre avancement (remplacez par "oui" si vous avez fini une étape)

La fontion gen_graphe() est faite et fonctionne
1>> non

La fonction visiter() est faite et fonctionne (les tests dans tests/README.txt sont ok) :
2>> non

La fonction trace_chemin() est faite et fonctionne :
3>> non

La fonction parcours_iteratif() est faite et fonctionne (les tests dans tests/README.txt sont ok) :
4>> non

L'animation du parcours fonctionne :
5>> non

Vérifiez la saisie de vos réponses en lançant le script :
./test_rendu.sh labyrinthe.c

Ne pas modifier cette ligne (nombre de questions):
nbq>>5
*/
/* A chaque fois que vous completez une fonction, vérifiez que cela
   fonctionne. Il y a des exemples de labyrinthes dans le répertoire
   ex_labys/ et le répertoire tests/ contient des exemples de résultats
   (lisez tests/README.txt pour plus d'infos).

Fonctions à completer (voir les détails dans l'énoncé du TP) :
   - gen_graphe() => vérifiez ensuite que le graphe est correct (option -t pour afficher le TLA et -d pour le dessiner).
   - visiter() pour le parcours récursif.
   - trace_chemin() : vérifiez que la longueur du chemin renvoyée est correcte.
   - parcours_iteratif() : pour les parcours itératifs en profondeur ou en largeur.
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <unistd.h>
#include "include/xmalloc.h"  /* pas besoin de regarder ce fichier */
#include "include/affichage.h"  /* pas besoin de regarder ce fichier */

#include "include/liste.h" /* contient les fonctions sur les listes */
#include "include/graphe_TLA.h" /* Structure Tgraphe et les fonctions pour
				   manipuler un graphe */
#include "include/parcours.h" /* Structure Tparcours qui contient entre
				 autre les tableaux couleur[], pere[], le
				 nombre de sommets explorés, ...*/
#include "include/laby.h" /* Structure Tlaby qui contient la matrice
			     décrivant le labyrinthe et le numéro de la case
			     finale. Fonctions pour générer un labyrinthe
			     aléatoire, lire un labyrinthe dans un fichier,
			     afficher le labyrinthe.*/



void milli_sleep(int n) {
  /* un appel à cette fonction met le processus en sommeil pendant n
     millisecondes, vous pouvez l'utiliser pour ralentir l'affichage dans
     le cas d'une animation du parcours. Il faudra l'appeler juste avant
     de réafficher un sommet. */
  struct timespec t;
  t.tv_sec = 0; 
  t.tv_nsec = 1000000*n; 
  nanosleep(&t,&t);
}

Tgraphe *gen_graphe(Tlaby *laby) {
  /* Retourne le graphe correspondant au labyrinthe passé en paramètre. */
  Tgraphe *g;

  /* crée un graphe sans arêtes avec le bon nombre de sommets */
  g = creer_graphe(laby->haut * laby->larg);
  /* il faut maintenant rajouter les arêtes */

  /* TODO */
  
  return g;
}
    

int visiter(Tgraphe *g, Tparcours *p, Tlaby *laby, int s) {
  /* Parcours en profondeur récursif du graphe g à partir du sommet s. */
  /* Retourne 1 si on trouve le sommet laby->fin et 0 sinon.
     Le parcours doit s'arrêter dès que le sommet laby->fin est trouvé. */
  /* Cette fonction doit mettre à jour les champs de p (couleur, pere, etc.). */
  /* le paramètre laby n'est utile que pour l'affichage s'il y a une
     animation du parcours (cf p->animation dans parcours.h). Dans ce cas,
     il faut utiliser la fonction reaffiche_sommet (dans laby.h) à chaque
     modification de la couleur d'un sommet. */
  
  /* TODO */
  return 0; /* à modifier */
}
 

int trace_chemin(Tparcours *p, int dest) {
  /* Met la valeur CHEMIN dans les cases de p->couleur[] par lesquelles
     passe le chemin de l'arborescence de parcours allant de la racine à dest
     et renvoie la longueur de celui-ci. CHEMIN est une pseudo-constante définie
     dans include/parcours.h

     On suppose que p->pere contient l'arborescence de parcours et que
     p->pere[racine] vaut 0.*/

  /* TODO */
  return 0; // à modifier
}

int parcours_iteratif(Tgraphe *g, Tparcours *p, Tlaby *laby, int s) {
  /*  Si p->algo vaut PROFONDEUR, fait un parcours itératif en profondeur.
      Si p->algo vaut LARGEUR, fait un parcours itératif en largeur.
      LARGEUR et PROFONDEUR sont définie dans include/parcours.h.
      Il faut utiliser les fonctions de include/liste.h pour gérer la
      liste des prochains sommets à explorer (soit en FIFO soit en
      LIFO). */
  /*  Pour récupérer un itérateur sur la liste des successeurs d'un
      sommet, utiliser liste_succ() définie dans include/graphe_TLA.h 
      (et voir include/liste.h pour les fonctions sur les itérateurs) */
  /*  Retourne 1 si on trouve le sommet laby->fin et 0 sinon.
      Le parcours doit s'arrêter dès que le sommet fin est trouvé. */


  /* TODO */
  return 0; // à modifier
}


void usage(int argc, char **argv) {
  fprintf(stderr,"Usage :\n   %s [Options] largeur hauteur proba [graine]\n",argv[0]);
  fprintf(stderr,         "   %s [Options] -f <fichier>\n",argv[0]);
  
  fprintf(stderr,"Dans le second cas (option \"-f\"), le labyrinthe est lu dans le fichier indiqué.\n\n");
    
  fprintf(stderr,"Options :\n");
  fprintf(stderr,"  -t : Affiche le TLA du graphe pour vérification.\n");
  fprintf(stderr,"  -d : dessine le graphe par dessus le laby (pour vérification).\n");
  fprintf(stderr,"Choix de l'algo de parcours :\n");
  fprintf(stderr,"  -l : pour un parcours en largeur ;\n");
  fprintf(stderr,"  -p : pour un parcours en profondeur ;\n");
  fprintf(stderr,"  -r : pour un parcours en profondeur récursif ;\n");
  fprintf(stderr,"  sinon, fait juste un affichage du labyrinthe.\n\n");
  fprintf(stderr,"Autres options (uniquement s'il y a un parcours), :\n");
  fprintf(stderr,"  -a   : fait une animation du parcours ;\n");
  fprintf(stderr,"  -w n : attend n ms avant chaque réaffichage du laby lors d'une animation;\n");
  exit(1);
}


int main(int argc, char **argv) {
  char *nom_fichier;
  char *nom_graphe="aléatoire";
  
  /* ************ traitement des paramètres de la ligne de commande *****/
  /* Chaque variable ci-dessous est initialisé en fonction des options
   * de la ligne de commande */
  int algo, animation, attente, dans_fichier, nb_algo, affiche_tla, dessine;
  algo = animation = attente = dans_fichier = nb_algo = affiche_tla = dessine = 0;
  /* comprendre le détail de cette partie n'est pas indispensable */
  /* pour avoir des infos sur getopt : "man 3 getopt" ou google...*/
  int option;
  while ((option = getopt(argc, argv, "f:lpraw:td")) != -1) 
    switch (option) {
    case 'd':
      dessine = 1;
      break;
    case 'f':
      dans_fichier = 1;
      nom_fichier = optarg;
      nom_graphe = optarg;
      break;
    case 'l':
      nb_algo++;
      algo = LARGEUR;
      break;
    case 'p':
      nb_algo++;
      algo = PROFONDEUR;
      break;
    case 'r':
      nb_algo++;
      algo = RECURSIF;
      break;
    case 'a':
      animation = 1;
      break;
    case 'w':
      attente = atoi(optarg);
      break;
    case 't':
      affiche_tla = 1;
      break;
    default:
      usage(argc, argv);
    }
  if (nb_algo > 1) {
    fprintf(stderr, "\n** Il faut sélectionner un seul algo de parcours\n\n");
    usage(argc, argv);
  }
  if (affiche_tla && animation) {
    fprintf(stderr, "\n** Animation (-a) et affichage du tla (-t) incompatibles\n\n");
    usage(argc, argv);
  }
  /* ************ fin traitement des paramètres   *************/

  /**************          Génération d'un labyrinthe aléatoire ou    **********
   **************           lecture du labyrinthe dans un fichier     **********
   ************** (en fonction des paramètres de la ligne de commande)  ********/
  Tlaby *laby;
  if (dans_fichier) { 
    /* Lecture du labyrinthe dans un fichier (option -f) */
    if (optind != argc) usage(argc, argv);
    FILE *fichier = fopen(nom_fichier,"r");
    if (fichier == NULL) {
      fprintf(stderr,"Pb lors de la lecture du fichier %s\n", nom_fichier);
      exit(1);
    }
    laby = lecture_laby(fichier);
    fclose(fichier);
    printf("Labyrinthe du fichier \"%s\": largeur = %d, hauteur = %d\n", 
	   nom_fichier, laby->larg, laby->haut);
  }
  else {
    /* Génération aléatoire du labyrinthe */
    int graine;
    if (optind + 4 == argc) 
      /* si la graine du générateur aléatoire est passée en paramètre, on la récupère */
      graine = atoi(argv[optind+3]);
    else if (optind + 3 == argc)
      /* sinon la graine est un xor entre heure actuelle et le PID */
      graine = (time(NULL) ^ getpid()) & 0xFFF;
    else
      usage(argc, argv);
    /* initialisation generateur aléatoire avec la graine */
    srandom(graine);
    /* récupére la largeur, hauteur et proba sur la ligne de commande */
    int larg = atoi(argv[optind]); 
    int haut = atoi(argv[optind+1]);
    double proba = atof(argv[optind+2]);
    laby = genere_laby_aleatoire(proba, larg, haut); 
    printf("Labyrinthe aléatoire : largeur = %d, hauteur = %d, proba = %.3f, graine = %d.\n",
	   larg, haut, proba, graine);
  } /************** fin génération ou lecture du labyrinthe ********/

  /************ Creation et initialisation de la structure Tparcours ***************/
  Tparcours *parcours = creer_parcours_vide(laby->haut * laby->larg);
  /* Recopie les options de la ligne de commande dans la structure parcours */
  parcours->algo = algo;              // choix de l'algo: options -l, -p ou -r
  parcours->animation = animation;    // option -a
  parcours->attente = attente;        // option -w
  parcours->dessine = dessine;        // option -d
  int depart = laby->larg + 2;     /* sommet de depart : 2e sommet de la 2e ligne */
  parcours->pere[depart] = 0;

  /* affichage du labyrinthe */
  affiche_legende_couleurs();
  affiche_laby(NULL, parcours, laby);
  
  /***************** Création du graphe à partir du labyrinthe *************/
  Tgraphe *graphe = gen_graphe(laby);
  if (affiche_tla)
    /* affiche le TLA du graphe si l'option -t est utilisée. */
    afficheTLA(graphe); 
  if (dessine) {
    /* reaffichage du laby avec le graphe par dessus si l'option -d est utilisée. */
    printf("\n\n");
    affiche_laby(graphe, parcours, laby);
  }
  /************************** fin création graphe *******************/

  /* si aucun algo de parcours sélectionné : c'est fini */
  if (nb_algo == 0) return 0;

  /* on lance le parcours */
  int long_chemin, existe_chemin;
  if (algo == RECURSIF) 
    existe_chemin = visiter(graphe, parcours, laby, depart);
  else /* algo vaut PROFONDEUR ou LARGEUR */
    existe_chemin = parcours_iteratif(graphe, parcours, laby, depart);

  if (existe_chemin) 
    /* si il existe un chemin, on le trace */
    long_chemin = trace_chemin(parcours, laby->fin);

  /* affichage du résultat */
  printf("\nGraphe après parcours :\n");
  affiche_laby(graphe, parcours, laby);
  printf("\n");
  if (existe_chemin) {
    printf("Il existe un chemin dans le graphe %s.\n", nom_graphe);
    printf("Longueur du chemin trouvé dans le graphe %s : %d\n", nom_graphe, long_chemin);
  }
  else {
    printf("Il n'existe pas de chemin dans le graphe %s.\n", nom_graphe);
  }
  printf("Nombre de sommets explorés dans le graphe %s : %d\n", nom_graphe, parcours->nb_sommets_explores);
  return 0;
}

