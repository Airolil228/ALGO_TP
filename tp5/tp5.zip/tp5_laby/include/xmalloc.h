#ifndef XMALLOC_H
#define XMALLOC_H

void *xmalloc(int l);
  /* Cette fonction fait comme malloc sauf qu'elle termine le programme en cas
     d'erreur */

#endif
