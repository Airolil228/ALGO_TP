Certains fichiers de ce répertoire contiennent des caractères spéciaux
(fichiers dont le nom commence par "log_").
Pour afficher le contenu de ces fichiers, utilisez la commande
less -R fichier
(en remplaçant fichier par le nom du fichier à afficher).
Par exemple :
less -R log_rec_laby1.txt

Pour les parcours récursifs et en profondeur, vos algorithmes ne
trouveront pas forcement les memes chemins. Cela dépend de l'ordre
dans lequel les successeurs d'un sommets ont été ajoutés dans le
graphe.  Du coup, faire un "diff" entre mes fichiers et les votres
donnera probablement beaucoup de différences.

******** Tests parcours récursif :
 Pour X un entier entre 1 et 4
 rec_labyX.txt : résultat de la commande :
 ./labyrinthe -r -f ./ex_labys/labyX.txt

 ** Pour tous les labyrinthes :
 Le fichier recursif_log.txt indique pour chaque labyrinthe s'il
 contient un chemin vers la case "X". Ici, votre algorithme doit
 trouver exactement la même chose.

 Vous pouvez utiliser la commande suivante pour générer votre version
 du fichier :
 ./tests_rec.sh > mon_recursif_log.txt
 et ensuite faire un diff. Les fichiers doivent être identiques.
 diff mon_recursif_log.txt recursif_log.txt

******** Tests parcours en profondeur itératif :
 Pour X un entier entre 1 et 4
 prof_labyX.txt : résultat de la commande :
 ./labyrinthe -p -f ./ex_labys/labyX.txt

 ** Pour tout les labyrinthes :
 pareil que pour le parcours recursif.
 ./tests_prof.sh > mon_profondeur_log.txt
 et ensuite faire un diff.

******** Parcours en largeur :
 Pour X un entier entre 1 et 4
 larg_labyX.txt : résultat de la commande :
 ./labyrinthe -l -f ./ex_labys/labyX.txt

 *** Pour tous les labyrinthes :

 largeur_log.txt contient la longueur des chemins trouvés. Ici, votre
 algorithme doit trouver exactement les mêmes longueurs de chemins et
 un nombre de sommets exploré très proche

 ./tests_larg.sh > mon_largeur_log.txt
 et ensuite faire un diff.

