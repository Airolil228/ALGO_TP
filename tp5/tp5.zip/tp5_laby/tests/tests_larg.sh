#!/bin/bash

cmd=$(basename "$0")
case $cmd in
    tests_larg.sh)
        algo="l"
        motif="chemin|Nombre"
        echo "Algorithme itératif en largeur";;
    tests_prof.sh)
        algo="p"
        motif="existe"
        echo "Algorithme itératif en profondeur";;
    tests_rec.sh)
        algo="r"
        motif="existe"
        echo "Algorithme récursif";;
esac
motifpc="chemin|Nombre"

for f in ../ex_labys/laby*[0-9].txt; do 
    echo "#### ../labyrinthe -$algo -f $f"
    ../labyrinthe -$algo -f $f |egrep "$motif"; 
    echo
done
for f in ../ex_labys/laby*pc.txt; do  # pas de chemin
    echo "#### ../labyrinthe -$algo -f $f"
    ../labyrinthe -$algo -f $f |egrep "$motifpc"; 
    echo
done
