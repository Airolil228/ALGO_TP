#!/bin/bash

for fich in graphes_exemples/*; do
            echo "#######  $fich"
            ./acpm "$fich" 2>&1 > /dev/null
            echo
done
