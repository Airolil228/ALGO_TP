#ifndef PRIOQ_H
#define PRIOQ_H

typedef struct fileprio Fprio;

/*
  Le type Fprio fournit une file à priorité et un tableau de valeurs.
  A chaque sommet est associé une valeur (aussi appelée priorité).
  La valeur de chaque sommet est stocké dans cette structure (y compris ceux qui ne sont pas dans la file).
  Les valeurs de tous les sommets sont initialisés à INT_MAX/2 lors de la création de la file.
   (INT_MAX/2 est un très grand entier qui joue le role de l'infini).
  La valeur associée à un sommet qui a été retiré de la liste est toujours accessible avec la fonction valeur().
 */


Fprio *creer_fprio(int nbe_max);
// Crée et retourne une file de priorité vide pouvant contenir jusqu'à nbe_max
// sommets numérotés de 1 à nbe_max. Les valeurs des sommets sont initialisés
// à INT_MAX/2.

int dans_fprio(Fprio *fq, int s);
// Retourne vrai si s est dans fp; on doit avoir 0 < s <= nbe_max.

void insere(Fprio *fp, int s);
// Insere un nouveau sommet s dans la file fp; on doit avoir 0 < s <= nbe_max.
// Erreur si le sommet est déjà dans la file.

int extraire_min(Fprio *fp);
// Retourne le sommet de valeur min dans fp (et le supprime de fp, sa valeur
// sera toujours accessible avec la fonction "valeur()")

int vide_fprio(Fprio *fp);
// Retourne vrai si la file est vide.


int valeur(Fprio *fp, int s);
// Retourne la valeur du sommet s; on doit avoir 0 < s <= nbe_max.
// Cette fonction peut etre utilisée meme si le sommet n'est pas dans la file.

void modif_val(Fprio *fp, int s, int nouvelle_valeur);
// Modifie la valeur associée à s; on doit avoir 0 < s <= nbe_max.
// Cette fonction peut etre utilisée meme si le sommet n'est pas dans la file.

long nb_perm();
/* renvoie le nombre d'opérations faites dans la file de priorité (pour
   faire des stats sur la complexité) */

#endif
