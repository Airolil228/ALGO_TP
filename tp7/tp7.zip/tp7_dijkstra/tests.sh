#!/bin/bash

for f in ex_labys/laby*; do
    echo ./dijkstra_laby -n -f $f 
    ./dijkstra_laby -n -f $f 
    echo
done

